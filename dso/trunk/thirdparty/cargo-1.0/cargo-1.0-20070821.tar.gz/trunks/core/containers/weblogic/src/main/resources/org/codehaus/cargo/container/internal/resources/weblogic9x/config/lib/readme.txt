This directory holds jar files that are added to the system classpath of the server, 
when the server�s Java virtual machine starts.
