This directory is an alternative to the config directory if the domain is set up so that configuration information 
is "user-staged", i.e. the administrator is responsible for staging (copying to the managed servers) 
the configuration information.
