#!/bin/bash
mvn install -Dmaven.test.skip=true
cd uberjar/target
jar xf cargo-core-uberjar-1.0-SNAPSHOT.jar
rm cargo-core-uberjar-1.0-SNAPSHOT.jar
for i in *.jar; do
  if [ -d $i ]; then
    cp -r -f $i/org .
  fi
done

jar cf cargo-core-uberjar-1.0-SNAPSHOT.jar org META-INF
cp cargo-core-uberjar-1.0-SNAPSHOT.jar ~/trunk/code/base/dso-container-tests/lib
