#!/bin/bash
mvn clean install -Dmaven.test.skip=true
jar=~/trunk/code/base/dependencies/lib/cargo-core-uberjar-0.9.jar
rm $jar
cp uberjar/target/cargo-core-uberjar-0.9.jar $jar
