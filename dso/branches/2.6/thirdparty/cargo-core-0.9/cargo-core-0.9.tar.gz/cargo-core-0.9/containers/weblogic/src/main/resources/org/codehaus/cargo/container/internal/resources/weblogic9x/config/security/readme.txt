This directory contains system modules for the security framework. It contains one security provider 
configuration extension for each of the kinds of security provider in the domain�s current realm.
